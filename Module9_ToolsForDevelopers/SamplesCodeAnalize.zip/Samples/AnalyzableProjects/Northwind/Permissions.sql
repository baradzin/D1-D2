﻿grant select on object::[Northwind].[Orders] to ReaderRole;
go
﻿CREATE NONCLUSTERED INDEX [PostalCode] ON [Northwind].[Employees] 
(
	[PostalCode] ASC
)
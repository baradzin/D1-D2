﻿CREATE NONCLUSTERED INDEX [ShippedDate] ON [Northwind].[Orders] 
(
	[ShippedDate] ASC
)
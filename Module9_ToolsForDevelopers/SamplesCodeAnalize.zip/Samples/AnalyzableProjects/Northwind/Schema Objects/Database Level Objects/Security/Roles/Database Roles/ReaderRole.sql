﻿CREATE ROLE [ReaderRole]

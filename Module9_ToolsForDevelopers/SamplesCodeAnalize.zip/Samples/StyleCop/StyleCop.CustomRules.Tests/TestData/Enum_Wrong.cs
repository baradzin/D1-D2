﻿enum MyEnu 
{ 
	A, B, C
}
﻿enum MyEnum 
{ 
	A, B, C
}
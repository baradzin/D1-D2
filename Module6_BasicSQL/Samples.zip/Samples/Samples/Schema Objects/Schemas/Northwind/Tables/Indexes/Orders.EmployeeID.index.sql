﻿CREATE NONCLUSTERED INDEX [EmployeeID] ON [Northwind].[Orders] 
(
	[EmployeeID] ASC
)
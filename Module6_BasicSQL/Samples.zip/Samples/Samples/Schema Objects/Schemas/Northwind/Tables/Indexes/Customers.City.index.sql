﻿CREATE NONCLUSTERED INDEX [City] ON [Northwind].[Customers] 
(
	[City] ASC
)
﻿CREATE NONCLUSTERED INDEX [SupplierID] ON [Northwind].[Products] 
(
	[SupplierID] ASC
)
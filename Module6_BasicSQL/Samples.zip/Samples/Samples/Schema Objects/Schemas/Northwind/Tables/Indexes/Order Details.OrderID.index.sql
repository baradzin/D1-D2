﻿CREATE NONCLUSTERED INDEX [OrderID] ON [Northwind].[Order Details] 
(
	[OrderID] ASC
)
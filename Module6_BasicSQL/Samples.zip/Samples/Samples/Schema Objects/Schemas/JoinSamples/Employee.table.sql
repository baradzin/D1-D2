﻿CREATE TABLE [JoinSamples].[Employee]
(
	[Id] INT NOT NULL PRIMARY KEY, 
	[LastName] NVARCHAR(50) NOT NULL, 
	[DepartmentID] INT NULL
)

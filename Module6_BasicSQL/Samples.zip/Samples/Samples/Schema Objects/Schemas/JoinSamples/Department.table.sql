﻿CREATE TABLE [JoinSamples].[Department]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [DepartmentName] VARCHAR(50) NOT NULL
)

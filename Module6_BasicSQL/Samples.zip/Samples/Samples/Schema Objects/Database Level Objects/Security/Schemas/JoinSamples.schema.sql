﻿CREATE SCHEMA [JoinSamples]

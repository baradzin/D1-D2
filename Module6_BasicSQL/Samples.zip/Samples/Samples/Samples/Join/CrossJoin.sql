﻿SELECT *
FROM JoinSamples.Employee CROSS JOIN JoinSamples.Department


SELECT * 
FROM JoinSamples.Employee, JoinSamples.Department

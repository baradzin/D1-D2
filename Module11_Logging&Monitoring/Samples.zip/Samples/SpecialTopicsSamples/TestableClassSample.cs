﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NLog;
using Moq;

namespace SpecialTopicsSamples
{
	[TestClass]
	public class TestableClassSample
	{
		[TestMethod]
		public void DiscardLogMessages()
		{
			var testableClass = new TestableClass(LogManager.CreateNullLogger());
			testableClass.MethodA();
		}


		[TestMethod]
		public void CheckLoggingLogic()
		{
			var loggerMock = new Mock<ILogger>() { };
			loggerMock.Setup(l => l.IsDebugEnabled).Returns(true);

			var testableClass = new TestableClass(loggerMock.Object);

			testableClass.MethodA();

			loggerMock.Verify(
				logger => logger.Debug(It.Is<string>(s => s == "Start MethodA")));
			loggerMock.Verify(
				logger => logger.Debug(It.Is<string>(s => s == "Finish MethodA")));
		}
	}
}

﻿using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecialTopicsSamples
{
	class TestableClass
	{
		readonly ILogger logger;

		public TestableClass(ILogger logger)
		{
			this.logger = logger;
		}

		public void MethodA()
		{
			if (logger.IsDebugEnabled)
				logger.Debug("Start MethodA");

			// Some code

			if (logger.IsDebugEnabled)
				logger.Debug("Finish MethodA");

		}
	}
}

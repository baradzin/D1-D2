﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NLog.Config;
using NLog;

namespace SpecialTopicsSamples
{
	[TestClass]
	public class InCodeConfigurationSamples
	{
		[TestMethod]
		public void NLogSample()
		{
			var config = new LoggingConfiguration();
			var fileTarget = new NLog.Targets.FileTarget() {
				Name = "FileTarget",
				FileName = "NLogFile.log",
				ArchiveAboveSize = 100000000,
				Layout = "${date} [${threadid}] ${level} ${logger} - ${message}"
			};
			config.AddTarget(fileTarget);
			config.LoggingRules.Add(new LoggingRule("*", LogLevel.Debug, fileTarget));

			LogManager.Configuration = config;

			var logger = LogManager.GetLogger("SimpleSamples");

			logger.Error("It's error");
		}
	}
}

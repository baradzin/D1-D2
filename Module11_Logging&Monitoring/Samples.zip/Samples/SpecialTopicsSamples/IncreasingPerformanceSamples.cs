﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NLog;

namespace SpecialTopicsSamples
{
	[TestClass]
	public class IncreasingPerformanceSamples
	{
		[TestMethod]
		public void TestMethod1()
		{
			var logger = LogManager.GetCurrentClassLogger();

			if (logger.IsErrorEnabled)
				logger.Error("It's error");

			if (logger.IsInfoEnabled)
				logger.Info("It's information");

			if (logger.IsDebugEnabled)
				logger.Debug("It's debug info");
		}
	}
}

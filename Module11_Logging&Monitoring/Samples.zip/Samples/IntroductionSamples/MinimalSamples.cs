﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;

namespace IntroductionSamples
{
	[TestClass]
	public class MinimalSamples
	{
		[TestMethod]
		public void Log4netSample()
		{
			log4net.Config.XmlConfigurator.Configure();
			var logger = log4net.LogManager.GetLogger("SimpleSamples");

			logger.Error("It's error");
		}


		[TestMethod]
		public void SystemDiagnosticsSample()
		{
			Trace.TraceError("It's error");

		}

		[TestMethod]
		public void SystemDiagnosticsNamingSourceSample()
		{
			var ts = new TraceSource("MinimalSamplesSource");

			ts.TraceEvent(TraceEventType.Error, 1, "It's error");
		}

	}
}

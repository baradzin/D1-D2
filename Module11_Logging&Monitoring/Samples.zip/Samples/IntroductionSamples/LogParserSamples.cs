﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace IntroductionSamples
{
	[TestClass]
	public class LogParserSamples
	{
		[TestMethod]
		public void SimpleQuery()
		{
			var logQuery = new MSUtil.LogQueryClass();
			var input = new MSUtil.COMEventLogInputContextClass();
			
			var resultDataSet = logQuery.Execute(
				"SELECT TimeGenerated, SourceName, EventID, Message " + 
				"FROM Application WHERE SourceName = 'ESENT' " + 
				"ORDER BY TimeGenerated DESC", 
				input);

			while (!resultDataSet.atEnd())
			{
				var record = resultDataSet.getRecord();
				Console.WriteLine("{0} : {1}", record.getValue(0), record.getValue("Message"));

				resultDataSet.moveNext();
			}
		}
	}
}

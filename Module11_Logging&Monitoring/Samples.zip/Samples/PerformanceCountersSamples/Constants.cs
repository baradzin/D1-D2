﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerformanceCountersSamples
{
    public static class Constants
    {
        public const string CategoryName = "Sample Category";
        public const string FirstCounterName = "First counter";
        public const string SecondCounterName = "Second counter";
    }
}

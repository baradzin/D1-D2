﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System.Threading;

namespace PerformanceCountersSamples
{
    [TestClass]
    public class UsePerformanceCounters
    {
        [TestMethod]
        public void SetCounter()
        {
            using (var logInCounter = new PerformanceCounter(
                Constants.CategoryName,
                Constants.FirstCounterName,
                "Test project",
                false))
            {
                logInCounter.RawValue = 0;

                for (var i = 0; i < 20; i++)
                {
                    Thread.Sleep(3000);
                    logInCounter.Increment();
                }
            }
        }


        [TestMethod]
        public void ReadCounter()
        {
            using (var logInCounter = new PerformanceCounter(
                "Processor",
                "% Processor Time",
                "_Total"))
            {
                for (var i = 0; i < 10; i++)
                {
                    Thread.Sleep(2000);
                    Console.WriteLine(logInCounter.NextValue());
                }
            }
        }
    }
}

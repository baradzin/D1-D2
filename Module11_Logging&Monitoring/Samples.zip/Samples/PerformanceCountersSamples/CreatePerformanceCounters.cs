﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System.Security;

namespace PerformanceCountersSamples
{
    [TestClass]
    public class CreatePerformanceCounters
    {        

        [TestMethod]
        public void GetCategories()
        {
            foreach (var category in PerformanceCounterCategory.GetCategories())
            {
                Console.WriteLine(category.CategoryName);
            }
        }

        [TestMethod]
        public void CreateCategory()
        {
            if (!PerformanceCounterCategory.Exists(Constants.CategoryName))
            {
                var counterCreationDataCollection = new CounterCreationDataCollection();

                var loginCounter = new CounterCreationData()
                {
                    CounterName = Constants.FirstCounterName,
                    CounterType = PerformanceCounterType.NumberOfItems32
                };
                counterCreationDataCollection.Add(loginCounter);

                var logofCounter = new CounterCreationData()
                {
                    CounterName = Constants.SecondCounterName,
                    CounterType = PerformanceCounterType.NumberOfItems32
                };
                counterCreationDataCollection.Add(logofCounter);

                try
                {
                    PerformanceCounterCategory.Create(
                        Constants.CategoryName, "",
                        PerformanceCounterCategoryType.MultiInstance,
                        counterCreationDataCollection);
                }
                catch (UnauthorizedAccessException)
                {
                    Console.WriteLine("Do not have permissions");
                }

                Console.WriteLine("Category created");
            }
        }

        [TestMethod]
        public void DeleteCategory()
        {
            if (PerformanceCounterCategory.Exists(Constants.CategoryName))
            {
                try
                {
                    PerformanceCounterCategory.Delete(Constants.CategoryName);
                }
                catch (UnauthorizedAccessException)
                {
                    Console.WriteLine("Do not have permissions");
                }

                Console.WriteLine("Category deleted");
            }
        }
    }
}

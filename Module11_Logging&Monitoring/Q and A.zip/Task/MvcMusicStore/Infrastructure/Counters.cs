﻿using PerformanceCounterHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcMusicStore.Infrastructure
{
    [PerformanceCounterCategory
        ("MvcMusicStor", 
        System.Diagnostics.PerformanceCounterCategoryType.MultiInstance,
        "MvcMusicStor")]
    public enum Counters
    {
        [PerformanceCounter
            ("Go to Home count",
            "Go to home",
            System.Diagnostics.PerformanceCounterType.NumberOfItems32
            )]
        GoToHome
    }
}